function Blocco(){
}