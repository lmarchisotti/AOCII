function accessoArray(iniziale, dimensione) {
    this.size = dimensione;
    this.starterValue = iniziale; 
}