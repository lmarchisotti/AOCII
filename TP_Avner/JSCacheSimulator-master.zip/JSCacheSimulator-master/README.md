# JSCacheSimulator
A Simple Javascript Cache Simulator

JSCacheSimulator shows how a processor cache works, how addresses are mapped into cache positions and blocks
are replaced, according to various parameters that can be set up for each simulation.

The simulator was written in HTML5, using JQuery and Bootstrap libraries. To use it, open the file "index.html"
(index.html) with a recent browser.

[run online](https://emavgl.github.io/JSCacheSimulator/)

[how to use the simulator](documentation.pdf)

